# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sssi']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'sssi',
    'version': '0.1.0',
    'description': '',
    'long_description': '# 301-Project 1 \n## Milestone 1\n\n###### Steps for Collab\n1. I create a new repo under one Github account of a member of our team.\n2. I have decided to use collab which is located https://colab.research.google.com/drive/1qLwhm5FAinETMUOtTnDyaDX2m8jD-q4F?authuser=1#scrollTo=tbaN8k2Dw9bv. Where I install NNI usung these lines of code:\n```\n! pip install nni # install nni\n! wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip # download ngrok and unzip it\n! unzip ngrok-stable-linux-amd64.zip\n! mkdir -p nni_repo\n! git clone https://github.com/microsoft/nni.git nni_repo/nni # clone NNI\'s offical repo to get examples\n```\n3. Now we must create a ngrok account. After creating the account you verify your email and then click the ***Your Authtoken*** shown on the left underneath ***Setup & Installation***\n4. You copy your authtoken and the paste it with this code\n```\n! ./ngrok authtoken YOUR_AUTH_TOKEN\n! nnictl create --config nni_repo/nni/examples/trials/mnist-pytorch/config.yml --port 5000 &\nget_ipython().system_raw(\'./ngrok http 5000 &\')\n! curl -s http://localhost:4040/api/tunnels # don\'t change the port number 4040\n```\n5. After running all the code you will see a url like http://xxxx.ngrok.io, after the last line of code and this will show the NNI\'s Web UI\n\n###### Steps for Poetry\n1. I create a new repo under one Github account of a member of our team.\n2. I install[https://python-poetry.org/docs/#installing-with-the-official-installer] and setup a new poetry porject with `poetry innit -n`\n3. Next we do `poetry shell` to be inside of the enviorment\n4. Now we install poetry and setup the enviorment and use `poetry add` to install the dependencies \n5. Here I add NNI using the method in step 4 and then run `nni hello` this will download the `nni_hello_hpo` and send a command message stating `Please run "python nni_hello_hpo/main.py" to try it out.`\n6. Finally you run that line and you will be prompted to two local links and those will be your NNI\'s Web UI\n\n## Milestone 2 \nFor this project we are using Unet which is a convolutional neural network meaning it is applied to visual images. In this case we will apply Unet to satelite imagery that were taken of several different locations ranging from cities to deserts and oceans. On the left is the image taken and the image on the right is the effect of Unet. \n`More can be viewed in docs/baseline-performance.md`\n<!-- Image here -->\n\n![Figure_1](https://user-images.githubusercontent.com/98928740/200205279-83f298a4-5592-41a7-91c8-15774bfcbc52.png)\n![Figure_2](https://user-images.githubusercontent.com/98928740/200205260-f1abc72a-ac6a-4091-a582-97a38e67fd38.png)\n\n',
    'author': 'AryanNesti',
    'author_email': 'aryannesti60@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<3.11',
}


setup(**setup_kwargs)
